package scit.zp.eetm.run;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.List;

import scit.zp.eetm.model.Data;
import scit.zp.my.tools.Tools;

public class TurnToSvmForm {
	public static void main(String[] args) {
		Data dat = (Data) Tools.readObject("H:\\eetm\\data-2-final.cls");
		List<String> label = Tools.readContentAsListPerLine("Y:\\eetm\\20news-bydate-all-label.txt");

		System.out.println(dat.content.length);
		System.out.println(label.size());

		try {
			PrintWriter pw = new PrintWriter("H:\\eetm\\20news-bydate-all-svm-v64-2-1.6.txt");
			for (int n = 0; n < dat.content.length; n++) {
				pw.print(label.get(n).trim() + " ");

				double[] gamma = Tools.clone(dat.gamma[n]);
				// Tools.normalize1Itn(gamma);

				for (int i = 0; i < dat.K; i++) {
					pw.print((i + 1) + ":" + gamma[i] + " ");
				}

				for (int i = 0; i < dat.K; i++) {
					double[] v = dat.theta[n][i];
					for (int j = 0; j < dat.V; j++)
						pw.print((dat.K + i * dat.V + j + 1) + ":" + v[j] + " ");
					// pw.print((i * dat.V + j + 1) + ":" + v[j] + " ");// theta
				}

				pw.println();
			}
			pw.flush();
			pw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			BufferedReader br = new BufferedReader(
					new InputStreamReader(new FileInputStream("H:\\eetm\\20news-bydate-all-svm-v64-2-1.6.txt")));
			PrintWriter pw = new PrintWriter("H:\\eetm\\20news-bydate-test-svm-v64-2-1.6.txt");
			for (int i = 0; i < 7532; i++)
				pw.println(br.readLine().trim());
			pw.flush();
			pw.close();

			pw = new PrintWriter("H:\\eetm\\20news-bydate-train-svm-v64-2-1.6.txt");
			for (String i = br.readLine(); null != i; i = br.readLine())
				pw.println(i.trim());
			pw.flush();
			pw.close();

			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
