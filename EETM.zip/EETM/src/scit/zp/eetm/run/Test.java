package scit.zp.eetm.run;

import scit.zp.eetm.model.Data;
import scit.zp.eetm.model.SaveData;
import scit.zp.eetm.model.StepE;
import scit.zp.eetm.model.StepM;
import scit.zp.eetm.model.StepSGD;
import scit.zp.my.management.Manager;
import scit.zp.my.tools.Tools;

public class Test {

	// @SuppressWarnings("unchecked")
	public static void main(String[] args) {
		System.out.println("Hello world! EETM");

		// List<String> content =
		// Tools.readContentAsListPerLine("/home/gpu/MyData/eetm/reuters-document-line.txt");
		// Tools.saveObject(content, "Y:\\eetm\\test-chn-content.cls");
		// content = (List<String>) Tools
		// .readObject("Y:\\eetm\\test-chn-content.cls");
		// System.out.println(content);
		// System.out.println("Read content done! " + content.size());

		// VectorModel vm =
		// Tools.readVector("/home/gpu/MyData/eetm/enwiki-snapshot-201703-2-v64.java.bin");
		// Tools.saveObject(vm, "Y:\\eetm\\wv.cls");
		// vm = (VectorModel) Tools.readObject("Y:\\eetm\\wv.cls");
		// System.out.println("Read Embedding done!");
		Data dat;// = new Data(content, vm, 30);
		// dat.alpha = .5d;
		// dat.epslon = 1.e-7;
		// Tools.saveObject(dat, "/home/gpu/MyData/eetm/reuters-dat.cls");
		// System.out.println("Init data Done!");
		// System.exit(0);
		// vm.vct.clear();
		// vm = null;
		// System.gc();
		dat = (Data) Tools.readObject("/home/gpu/MyData/eetm/data.cls");
		System.out.println("Load data done!");
		// dat.beta = 1000.d;
		// dat.alpha = 25.d / dat.K;
		// dat.delta = .1d;
		dat.maxItv = 256;
		System.out.println(dat.alpha + " " + dat.beta + " " + dat.delta);

		// dat.beta = 0.01d;
		// dat.delta = 0.001d;
		// Tools.saveObject(dat, "D:\\eetm\\dat.cls");

		Manager<Data> mng = new Manager<Data>(dat);
		mng.addStep(new StepE());// Step-0
		mng.addStep(new StepM());// Step-1
		mng.addStep(new StepSGD());// Step-2
		mng.addStep(new SaveData("/home/gpu/MyData/eetm/data.cls"));// Step-4

		// mng.runStep(2);
		// System.out.println("Initialization done!");
		System.out.println("Start iteration!");
		mng.iterative(2000);
		System.out.println("Saving final result.");
		Tools.saveObject(dat, "/home/gpu/MyData/eetm/reuters-dat-final.cls");
	}
}
