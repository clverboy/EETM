package scit.zp.eetm.run;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;

import scit.zp.eetm.model.Data;
import scit.zp.my.tools.Tools;

public class SaveData {

	public static void main(String[] args) {
		Data dat = (Data) Tools.readObject("D:\\eetm\\test-chn-data.cls");

		try {
			DataOutputStream dos = new DataOutputStream(
					new BufferedOutputStream(new FileOutputStream(
							"D:\\eetm\\wv.bin")));
			dos.writeInt(dat.embedding.length);
			dos.writeInt(dat.V);

			for (int i = 0; i < dat.embedding.length; i++) {
				dos.writeUTF(dat.idx2w.get(i));
				for (int j = 0; j < dat.V; j++)
					dos.writeFloat((float) dat.embedding[i][j]);
			}
			dos.flush();
			dos.close();

			PrintWriter pw = new PrintWriter("D:\\eetm\\test-chn.txt");
			for (String[] i : dat.content) {
				for (String w : i)
					pw.print(w.trim() + " ");
				pw.println();
			}
			pw.flush();
			pw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
