package scit.zp.eetm.run;

import java.io.PrintWriter;

import scit.zp.eetm.model.Data;
import scit.zp.eetm.model.Tau;
import scit.zp.my.tools.Tools;

public class PrintResult {

	public static void main(String[] args) {
		Data dat = (Data) Tools.readObject("D:\\eetm\\data-final.cls");
		String prt = "D:\\eetm\\result\\";

		for (int doc = 0; doc < dat.doc.length; doc++)
			try {
				PrintWriter pw = new PrintWriter(prt + doc + ".txt");
				for (int n = 0; n < dat.content[doc].length; n++) {
					pw.print(dat.content[doc][n] + " ");
					pw.println(dat.idx2w.get(dat.doc[doc][n]) + " ");
					// double sumGamma = Tools.normal1(dat.gamma[doc]);
					// int widx = dat.doc[doc][n];
					double sum = 0.d;
					for (int i = 0; i < dat.K; i++)
						sum += Tau.tau(dat.embedding[dat.doc[doc][n]], dat.theta[doc][i], dat.theta[doc]);
					for (int i = 0; i < dat.K; i++) {
						// double psi = Tools.digamma(dat.gamma[doc][i])
						// - Tools.digamma(sumGamma);

						pw.print(String.format("%.7f", dat.phi[doc][n][i]) + "/"
								+ String.format(
										"%.7f",
										Tau.tau(dat.embedding[dat.doc[doc][n]], dat.theta[doc][i],
												dat.theta[doc]))
								+ "/"
								+ String.format("%.7f",
										Tau.tau(dat.embedding[dat.doc[doc][n]], dat.theta[doc][i], dat.theta[doc])
												/ sum)
								+ " ");
					}
					pw.println();
				}
				pw.flush();
				pw.close();
			} catch (Exception e) {

			}
	}

}
