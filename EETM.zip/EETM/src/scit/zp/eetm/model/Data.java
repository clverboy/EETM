package scit.zp.eetm.model;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import scit.zp.my.tools.Tools;

public class Data implements Serializable {
	private static final long serialVersionUID = -8379076868464530880L;

	public double alpha = 0.1d, beta = 0.01d, epslon = 1.e-6, delta = 0.1d, radius = 7.d;
	public int K, V, maxItv = 500;

	public String content[][];// content[M][Nd]
	public int doc[][];// doc[M][Nd]
	public Map<String, Integer> w2idx;
	public Map<Integer, String> idx2w;

	public double gamma[][];// gamma[doc][k]
	public double phi[][][];// phi[doc][Nd][k]
	public double zeta[][];// zeta[k][word]
	public double embedding[][];// embedding[word][V]
	public double theta[][][];// theta[doc][K][V]

	public Data(List<String> Content, VectorModel Embedding, int k) {
		this.K = k;
		this.V = Embedding.volume;
		this.content = new String[Content.size()][];
		this.doc = new int[Content.size()][];

		this.gamma = new double[this.doc.length][this.K];
		this.phi = new double[this.doc.length][][];
		this.zeta = new double[this.K][];
		this.theta = new double[this.doc.length][this.K][];

		this.w2idx = new TreeMap<String, Integer>();
		this.idx2w = new TreeMap<Integer, String>();

		for (int i = 0; i < this.content.length; i++) {
			this.content[i] = Content.get(i).split("\\s+");
			this.doc[i] = new int[this.content[i].length];
			this.phi[i] = new double[this.content[i].length][this.K];

			for (int j = 0; j < this.content[i].length; j++) {
				String w = this.content[i][j].trim();
				if (!this.w2idx.containsKey(w)) {
					this.w2idx.put(w, this.w2idx.size());
					this.idx2w.put(this.w2idx.get(w), w);
				}
				this.doc[i][j] = this.w2idx.get(w);
			}
		}

		this.embedding = new double[this.w2idx.size()][];
		double v0[] = Tools.zeroVector(this.V);
		for (int i : this.idx2w.keySet())
			if (Embedding.vct.containsKey(this.idx2w.get(i))) {
				this.embedding[i] = Embedding.vct.get(this.idx2w.get(i));
				Tools.normalize2Itn(this.embedding[i]);
			} else
				this.embedding[i] = v0;

		for (int i = 0; i < this.K; i++)
			// this.zeta[i] = Tools.set(new double[this.w2idx.size()], 1.d /
			// this.w2idx.size());
			this.zeta[i] = Tools.randomProbability(this.w2idx.size());
		for (int i = 0; i < this.theta.length; i++)
			for (int j = 0; j < this.K; j++) {
				// int ran = Math.round((float) Math.random() *
				// (this.doc[i].length - 1));
				// Tools.valueCopy(this.theta[i][j],
				// this.embedding[this.doc[i][ran]]);
				this.theta[i][j] = Tools.randomVector(this.V);
				Tools.valueMultipleItn(Tools.normalize2Itn(this.theta[i][j]), this.radius);
			}

		// for (int i = 0; i < this.doc.length; i++)
		// new initTheta(i);
		this.alpha = 50.d / this.K;
		this.beta = 200.d / this.w2idx.size();
	}

	// private class initTheta extends Thread {
	// private int docIdx;
	//
	// public initTheta(int i) {
	// this.docIdx = i;
	// this.start();
	// try {
	// Thread.sleep(5);
	// } catch (InterruptedException e) {
	// e.printStackTrace();
	// }
	// }
	//
	// @Override
	// public void run() {
	// this.Kmeans(this.docIdx);
	// }
	//
	// private void Kmeans(int didx) {
	// int[] wds = doc[didx];
	// double tht[][] = theta[didx];
	//
	// int[] wcls = new int[wds.length];
	// double[] maxSim = new double[wds.length];
	//
	// while (true) {
	// boolean done = true;
	// for (int n = 0; n < wds.length; n++) {
	// double[] emb = embedding[wds[n]];
	//
	// for (int i = 0; i < K; i++) {
	// double sim = Tau.tau(emb, tht[i], tht);
	// if (sim > maxSim[n]) {
	// maxSim[n] = sim;
	// wcls[n] = i;
	// done = false;
	// }
	// }
	// }
	// if (done)
	// break;
	// for (int i = 0; i < K; i++)
	// Tools.set(tht[i], 0);
	// for (int n = 0; n < wds.length; n++)
	// Tools.addItn(tht[wcls[n]], embedding[wds[n]]);
	// for (int i = 0; i < K; i++)
	// Tools.normalize2Itn(tht[i]);
	// }
	// System.out.println("Init theta done for doc " + this.docIdx);
	// }
	// }

}
