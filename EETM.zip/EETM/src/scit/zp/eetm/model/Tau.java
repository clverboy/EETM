package scit.zp.eetm.model;

import scit.zp.my.tools.Tools;

public class Tau {
	private Tau() {
	}

	public static double tau(double[] w, double[] t, double[][] theta) {
		// Softmax kernel
		// return Tools.sigmoid(w, t);

		// double x = 1.d + (theta.length - 1.d) *
		// Math.exp(-Tools.interMultiple(w, t));
		// x = 1.d / x;
		// return x;

		double sum = 1.d;
		for (double[] i : theta)
			sum += Math.exp(Tools.interMultiple(i, w));
		return Math.exp(Tools.interMultiple(w, t)) / sum;

		// Gauss kernel
		// return Math.exp(-.5d * Tools.normal2(Tools.minus(w, t)));

	}

	public static double tau1(double[] w, double[] t) {
		// Softmax kernel
		return Math.exp(Tools.interMultiple(w, t));

		// Gauss kernel
		// return Math.exp(-.5d * Tools.normal2(Tools.minus(w, t)));

	}

	public static double[] gradient(double[] w, double[] t, double[][] theta, double p) {
		// Softmax kernel
		double x = tau(w, t, theta);
		x = 1.d + p - (2.d * x);
		return Tools.valueMultiple(w, x);

		// Gauss kernel
		// double x = tau(w, t, theta);
		// return Tools.valueMultipleItn(Tools.minus(w, t), x);
	}
}
