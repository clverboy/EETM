package scit.zp.eetm.model;

import java.util.Map;
import java.util.TreeMap;

import scit.zp.my.management.Pool;
import scit.zp.my.management.Step;
import scit.zp.my.tools.Tools;

public class StepM extends Step<Data> {
	private Pool POOL = new Pool();

	@Override
	public boolean call() {
		System.out.println(Tools.time() + " Step M");
		Tools.set(this.dat.zeta, this.dat.beta);
		this.POOL.reset();
		for (int d = 0; d < this.dat.doc.length; d++)
			new doc(d).start();
		this.POOL.waitExt();
		for (int i = 0; i < this.dat.K; i++)
			Tools.normalize1Itn(this.dat.zeta[i]);
		return false;
	}

	private class doc extends Thread {
		int d;

		public doc(int didx) {
			this.d = didx;
			POOL.waitCrt();
			POOL.creat();
		}

		@Override
		public void run() {
			int cont[] = dat.doc[this.d];// cont[Nd]
			double phi[][] = dat.phi[this.d];// phi[Nd][K]
			// double theta[][] = dat.theta[this.d];// theta[K][V]

			Map<Integer, Double> zetaJ = new TreeMap<Integer, Double>();
			for (int i = 0; i < dat.K; i++) {
				zetaJ.clear();
				for (int n = 0; n < cont.length; n++) {
					int widx = cont[n];
					double x = phi[n][i];
					if (!zetaJ.containsKey(widx))
						zetaJ.put(widx, x);
					else {
						double _tmp = x + zetaJ.get(widx);
						zetaJ.put(widx, _tmp);
					}
				}
				synchronized (dat.zeta[i]) {
					for (Map.Entry<Integer, Double> e : zetaJ.entrySet())
						dat.zeta[i][e.getKey()] += e.getValue();
				}
			}
			POOL.exit();
		}
	}

}
