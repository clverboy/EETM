package scit.zp.eetm.model;

import java.io.Serializable;
import java.util.Map;

public class VectorModel implements Serializable {
	private static final long serialVersionUID = -3549943507597127499L;

	public int wordCount;
	public int volume;
	public Map<String, double[]> vct;
}
