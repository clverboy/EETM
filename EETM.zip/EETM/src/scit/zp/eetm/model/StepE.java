package scit.zp.eetm.model;

import scit.zp.my.management.Pool;
import scit.zp.my.management.Step;
import scit.zp.my.tools.Tools;

public class StepE extends Step<Data> {
	private Pool POOL = new Pool();

	@Override
	public boolean call() {
		System.out.println(Tools.time() + " Step E");
		this.POOL.reset();
		for (int d = 0; d < this.dat.doc.length; d++)
			new doc(d).start();
		this.POOL.waitExt();
		return false;
	}

	private class doc extends Thread {
		int d;

		public doc(int didx) {
			this.d = didx;
			POOL.waitCrt();
			POOL.creat();
		}

		@Override
		public void run() {
			// System.out.println("Start doc " + this.d);
			int cont[] = dat.doc[this.d];// cont[Nd]
			double gamma[] = dat.gamma[this.d];// gamma[K]
			double phi[][] = dat.phi[this.d];// phi[Nd][K]
			double theta[][] = dat.theta[this.d];// theta[K][V]

			for (double[] i : phi)
				for (int j = 0; j < dat.K; j++)
					i[j] = 1.d / dat.K;
			for (int j = 0; j < dat.K; j++)
				gamma[j] = dat.alpha + 1.d * cont.length / dat.K;

			double tauX[][] = new double[cont.length][dat.K];
			for (int n = 0; n < cont.length; n++) {
				int widx = cont[n];
				for (int i = 0; i < dat.K; i++)
					tauX[n][i] = Tau.tau(dat.embedding[widx], theta[i], theta);
				// Tools.normalize1Itn(tauX[n]);
			}

			for (int time = 0; time < dat.maxItv; time++) {
				for (int n = 0; n < cont.length; n++) {
					int widx = cont[n];
					for (int i = 0; i < dat.K; i++) {
						double x = tauX[n][i];
						x = x / (1.d - x);
						phi[n][i] = x * dat.zeta[i][widx] * Math.exp(Tools.digamma(gamma[i]));
					}
					Tools.normalize1Itn(phi[n]);
				}

				double oldGamma[] = Tools.clone(gamma);
				Tools.set(gamma, dat.alpha);

				for (int n = 0; n < cont.length; n++)
					Tools.addItn(gamma, phi[n]);

				if (Tools.maxChange(gamma, oldGamma) < dat.epslon)
					break;
			}

			POOL.exit();
			// System.out.println("Done doc " + this.d);
		}
	}

}
