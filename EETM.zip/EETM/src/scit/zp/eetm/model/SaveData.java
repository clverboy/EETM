package scit.zp.eetm.model;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

import scit.zp.my.management.Step;
import scit.zp.my.tools.Tools;

public class SaveData extends Step<Data> {
	public String savePath;
	public long timeStamp = System.currentTimeMillis();
	public long timeInternal = 1000 * 60 * 30;// 30Minites

	public SaveData(String path) {
		this.savePath = path;
	}

	@Override
	public boolean call() {
		if (this.timeInternal < System.currentTimeMillis() - this.timeStamp) {
			System.out.print(Tools.time() + " Saving data object: " + this.savePath);
			try {
				ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(this.savePath));
				oos.writeObject(this.dat);
				oos.flush();
				oos.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			this.timeStamp = System.currentTimeMillis();
			System.out.println(" - Done!");
		}

		System.gc();
		return false;
	}

}
