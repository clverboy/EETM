package scit.zp.eetm.model;

import scit.zp.my.management.Pool;
import scit.zp.my.management.Step;
import scit.zp.my.tools.Tools;

public class StepSGD extends Step<Data> {
	private Pool POOL = new Pool();
	private double ChangeAll;

	@Override
	public boolean call() {
		System.out.println(Tools.time() + " Step SGD");
		this.ChangeAll = 0.d;
		this.POOL.reset();
		for (int d = 0; d < this.dat.doc.length; d++)
			new doc(d).start();
		this.POOL.waitExt();
		this.ChangeAll = this.ChangeAll / this.dat.V / this.dat.K
				/ this.dat.doc.length;
		System.out.println(Tools.time() + " Vector mean change: "
				+ this.ChangeAll);
		return this.ChangeAll > this.dat.epslon;
	}

	private class doc extends Thread {
		int d;

		public doc(int didx) {
			this.d = didx;
			POOL.waitCrt();
			POOL.creat();
		}

		@Override
		public void run() {
			int cont[] = dat.doc[this.d];// cont[Nd]
			// double gamma[] = dat.gamma[this.d];// gamma[K]
			double phi[][] = dat.phi[this.d];// phi[Nd][K]
			double theta[][] = dat.theta[this.d];// theta[K][V]
			double sumChange = 0.d;
			double oriTheta[][] = Tools.clone(theta);

			for (int time = 0; time < dat.maxItv; time++) {
				double[][] oldTheta = Tools.clone(theta);

				for (int n = 0; n < cont.length; n++) {
					int widx = cont[n];
					double[] w = dat.embedding[widx];

					for (int i = 0; i < dat.K; i++) {
						double p = phi[n][i];
						Tools.addItn(theta[i], Tools.valueMultipleItn(
								Tau.gradient(w, theta[i], theta, p), dat.delta));
						if (Tools.normal2(theta[i]) > dat.radius)
							Tools.valueMultipleItn(
									Tools.normalize2Itn(theta[i]), dat.radius);
					}

				}

				double cg = 0.d;
				for (int i = 0; i < oldTheta.length; i++) {
					cg = Math.max(cg, Tools.maxChange(oldTheta[i], theta[i]));
				}
				if (cg < dat.epslon)
					break;
			}

			for (int i = 0; i < oriTheta.length; i++) {
				Tools.minusItn(oriTheta[i], theta[i]);
				sumChange += Tools.normal1(oriTheta[i]);
			}

			synchronized (POOL) {
				ChangeAll += sumChange;
			}

			POOL.exit();
		}
	}
}
