package scit.zp.my.tools;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;

import scit.zp.eetm.model.VectorModel;

/**
 * Static functions
 * 
 * @author zhPeng
 *
 */
public final class Tools {
	/**
	 * Tools class does not permit inherit and instantiation.
	 */
	private Tools() {
	}

	/**
	 * @return current time string
	 */
	public static String time() {
		Date nowTime = new Date(System.currentTimeMillis());
		SimpleDateFormat sdFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
		String retStrFormatNowDate = sdFormatter.format(nowTime);

		return retStrFormatNowDate;
	}

	/**
	 * 
	 * @param a
	 * @param b
	 * @return a, a[i]=b[i]
	 */
	public static double[] valueCopy(double[] a, double[] b) {
		if (null == a || null == b || a.length != b.length)
			return null;

		for (int i = 0; i < a.length; i++)
			a[i] = b[i];
		return a;
	}

	/**
	 * @param a
	 * @param x
	 * @return set a[i][j]=x
	 */
	public static double[][] set(double a[][], double x) {
		if (null == a)
			return null;
		for (int i = 0; i < a.length; i++)
			if (null != a[i])
				for (int j = 0; j < a[i].length; j++)
					a[i][j] = x;
		return a;
	}

	/**
	 * @param a
	 * @param x
	 * @return set a[i]=x
	 */
	public static double[] set(double a[], double x) {
		if (null == a)
			return null;
		for (int i = 0; i < a.length; i++)
			a[i] = x;
		return a;
	}

	/**
	 * @param a
	 * @return b=a
	 */
	public static double[] clone(double a[]) {
		if (null == a)
			return null;
		double[] b = new double[a.length];
		for (int i = 0; i < b.length; i++)
			b[i] = a[i];
		return b;
	}

	/**
	 * 
	 * @param a
	 * @return b=a
	 */
	public static double[][] clone(double a[][]) {
		if (null == a)
			return null;
		double[][] b = new double[a.length][];
		for (int i = 0; i < b.length; i++)
			if (null != a[i]) {
				b[i] = new double[a[i].length];
				for (int j = 0; j < b[i].length; j++)
					b[i][j] = a[i][j];
			}
		return b;
	}

	/**
	 * Zero vector.
	 * 
	 * @param v
	 * @return 0<sup>v</sup>
	 */
	public static double[] zeroVector(int v) {
		if (v <= 0)
			return null;
		double[] vct = new double[v];
		for (int i = 0; i < vct.length; i++)
			vct[i] = 0.f;
		return vct;
	}

	/**
	 * @param v
	 * @return 1<sup>v</sup>
	 */
	public static double[] identityVector(int v) {
		double[] s = new double[v];
		for (int i = 0; i < s.length; i++)
			s[i] = 1.d;
		return s;
	}

	/**
	 * @param v
	 * @return (-1,1)<sup>v</sup>
	 */
	public static double[] randomVector(int v) {
		double[] s = new double[v];
		for (int i = 0; i < s.length; i++)
			s[i] = Math.random() * ((Math.random() < 0.5d) ? -1 : 1);
		return s;
	}

	/**
	 * @param v
	 * @return [0,1)<sup>v</sup> with all components sum to 1
	 */
	public static double[] randomProbability(int v) {
		double[] p = new double[v];
		double sum = 0;
		for (int i = 0; i < p.length; i++) {
			p[i] = Math.random();
			sum += p[i];
		}
		for (int i = 0; i < p.length; i++)
			p[i] = p[i] / sum;
		return p;
	}

	/**
	 * Check error value in a.
	 * 
	 * @param a
	 * @return <I>true</I> only if null==a or any value in a is Infinite/NaN
	 */
	public static boolean isValueError(double[] a) {
		if (null == a)
			return true;
		for (int i = 0; i < a.length; i++)
			if (Double.isInfinite(a[i]) || Double.isNaN(a[i]))
				return true;
		return false;
	}

	/**
	 * Print a to console as out stream.
	 * 
	 * @param a
	 */
	public static void printVector(double[] a) {
		if (null == a || a.length < 1)
			return;
		for (double i : a)
			System.out.print(i + " ");
		System.out.println();
	}

	/**
	 * @param a
	 * @param b
	 * @return max[abs(a<sub>i</sub>-b<sub>i</sub>)]
	 */
	public static double maxChange(double a[], double b[]) {
		if (null == a || null == b || a.length != b.length)
			return 1.e300;

		double c = 0.d;
		for (int i = 0; i < a.length; i++)
			c = Math.max(c, Math.abs(a[i] - b[i]));
		return c;
	}

	/**
	 * @param a
	 * @return ||a||<sub>2</sub>
	 */
	public static double normal2(double[] a) {
		if (null == a || a.length < 1)
			return Double.NaN;

		double sum = 0.d;
		for (double i : a)
			sum += i * i;
		sum = Math.sqrt(sum);
		return sum;
	}

	/**
	 * @param a
	 * @return ||a||<sub>1</sub>
	 */
	public static double normal1(double[] a) {
		if (null == a || a.length < 1)
			return Double.NaN;

		double sum = 0.d;
		for (double i : a)
			sum += Math.abs(i);
		return sum;
	}

	/**
	 * @param a
	 * @return a=a/||a||<sub>2</sub>
	 */
	public static double[] normalize2Itn(double[] a) {
		if (null == a || a.length < 1)
			return null;

		double sum = 0.d;
		for (double i : a)
			sum += i * i;
		sum = Math.sqrt(sum);

		if (sum > .000000000001d)
			for (int i = 0; i < a.length; i++)
				a[i] = a[i] / sum;
		return a;
	}

	/**
	 * @param a
	 * @return a=a/||a||<sub>1</sub>
	 */
	public static double[] normalize1Itn(double[] a) {
		if (null == a || a.length < 1)
			return null;

		double sum = 0.d;
		for (double i : a)
			sum += Math.abs(i);

		if (sum > .000000000001d)
			for (int i = 0; i < a.length; i++)
				a[i] = a[i] / sum;
		return a;
	}

	/**
	 * @param a
	 * @param b
	 * @return c=a+b
	 */
	public static double[] add(double[] a, double[] b) {
		if (null == a || null == b || a.length != b.length)
			return null;

		double c[] = new double[a.length];
		for (int i = 0; i < a.length; i++)
			c[i] = a[i] + b[i];

		return c;
	}

	/**
	 * @param a
	 * @param b
	 * @return a=a+b
	 */
	public static double[] addItn(double[] a, double[] b) {
		if (null == a || null == b || a.length != b.length)
			return null;

		for (int i = 0; i < a.length; i++)
			a[i] += b[i];

		return a;
	}

	/**
	 * @param a
	 * @param b
	 * @return c=a-b
	 */
	public static double[] minus(double[] a, double[] b) {
		if (null == a || null == b || a.length != b.length)
			return null;

		double c[] = new double[a.length];
		for (int i = 0; i < a.length; i++)
			c[i] = a[i] - b[i];

		return c;
	}

	/**
	 * @param a
	 * @param b
	 * @return a=a-b
	 */
	public static double[] minusItn(double[] a, double[] b) {
		if (null == a || null == b || a.length != b.length)
			return null;

		for (int i = 0; i < a.length; i++)
			a[i] = a[i] - b[i];

		return a;
	}

	/**
	 * @param a
	 * @param b
	 * @return v=a<sup>T</sup>b
	 */
	public static double interMultiple(double[] a, double[] b) {
		if (null == a || null == b || a.length != b.length)
			return Double.NaN;
		double r = 0.d;
		for (int i = 0; i < a.length; i++)
			r += a[i] * b[i];
		return r;
	}

	/**
	 * @param a
	 * @param b
	 * @return c=b[a]
	 */
	public static double[] valueMultiple(double[] a, double b) {
		if (null == a)
			return null;

		double c[] = new double[a.length];
		for (int i = 0; i < c.length; i++)
			c[i] = a[i] * b;

		return c;
	}

	/**
	 * @param a
	 * @param b
	 * @return a=b[a]
	 */
	public static double[] valueMultipleItn(double[] a, double b) {
		if (null == a)
			return null;

		for (int i = 0; i < a.length; i++)
			a[i] *= b;

		return a;
	}

	/**
	 * @param a
	 * @param b
	 * @return c=a*b/|b|
	 */
	public static double[] projection(double[] a, double[] b) {
		if (null == a || null == b || a.length != b.length)
			return null;
		double sum = 0.d;
		double mul = 0.d;
		for (int i = 0; i < b.length; i++) {
			sum += b[i] * b[i];
			mul += a[i] * b[i];
		}
		mul = mul / Math.sqrt(sum);
		double c[] = new double[b.length];

		if (Double.isInfinite(mul) || Double.isNaN(mul))
			for (int i = 0; i < b.length; i++)
				c[i] = 0.d;
		else
			for (int i = 0; i < b.length; i++)
				c[i] = mul * b[i];

		return c;
	}

	/**
	 * @param v
	 * @return log<sub>2</sub>v
	 */
	public static double maxEntropy(int v) {
		return Math.log(v) / Math.log(2.d);
	}

	/**
	 * @param p
	 * @return -&Sigma;<sub>i</sub>p<sub>i</sub>log<sub>2</sub>p<sub>i</sub>
	 */
	public static double entropy(double[] p) {
		if (null == p)
			return Double.POSITIVE_INFINITY;

		double res = 0.d;
		for (double i : p)
			if (i > 0.d)
				res -= i * Math.log(i) * 1.4426950408889634d;
		return res;
	}

	/**
	 * @param w
	 * @param x
	 * @return [1+exp(-w<sup>T</sup>x)]<sup>-1</sup>
	 */
	public static double sigmoid(double[] w, double[] x) {
		return 1.d / (1.d + Math.exp(-interMultiple(w, x)));
	}

	/**
	 * @param w
	 * @param x
	 * @return exp[-0.5(w-x)<sup>2</sup>]
	 */
	public static double gaussKernel(double[] w, double[] x) {
		if (null == w || null == x || w.length != x.length)
			return Double.NaN;
		double s = 0.d;
		for (int i = 0; i < x.length; i++)
			s += (w[i] - x[i]) * (w[i] - x[i]);
		return Math.exp(-0.5d * s);
	}

	/**
	 * @param x
	 * @return log&Gamma;(x)
	 */
	public static double logGamma(double x) {
		double z = 1 / (x * x);

		x = x + 6;
		z = (((-0.000595238095238 * z + 0.000793650793651) * z - 0.002777777777778) * z + 0.083333333333333) / x;
		z = (x - 0.5) * Math.log(x) - x + 0.918938533204673 + z - Math.log(x - 1) - Math.log(x - 2) - Math.log(x - 3)
				- Math.log(x - 4) - Math.log(x - 5) - Math.log(x - 6);
		return z;
	}

	/**
	 * @param x
	 * @return &Psi;(x)=[log&Gamma;(x)]'=d[log&Gamma;(x)]/dx
	 */
	public static double digamma(double x) {
		double p;
		x = x + 6;
		p = 1 / (x * x);
		p = (((0.004166666666667 * p - 0.003968253986254) * p + 0.008333333333333) * p - 0.083333333333333) * p;
		p = p + Math.log(x) - 0.5 / x - 1 / (x - 1) - 1 / (x - 2) - 1 / (x - 3) - 1 / (x - 4) - 1 / (x - 5)
				- 1 / (x - 6);
		return p;
	}

	/**
	 * @param x
	 * @return &Psi;'(x)=d[&Psi;(x)]/dx
	 */
	public static double trigamma(double x) {
		double p;
		int i;

		x = x + 6;
		p = 1 / (x * x);
		p = (((((0.075757575757576 * p - 0.033333333333333) * p + 0.0238095238095238) * p - 0.033333333333333) * p
				+ 0.166666666666667) * p + 1) / x + 0.5 * p;
		for (i = 0; i < 6; i++) {
			x = x - 1;
			p = 1 / (x * x) + p;
		}
		return (p);
	}

	/**
	 * @param file
	 *            path
	 * @param cs
	 *            encode
	 * @return list of content
	 */
	public static List<String> readContentAsListPerLine(File file, String cs) {
		List<String> lst = new ArrayList<String>();
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), cs));
			for (String i = br.readLine(); null != i; i = br.readLine())
				lst.add(i.trim());
			br.close();
		} catch (Exception e) {
			System.err.println("Error in readContentAsListPerLine!");
			e.printStackTrace();
		}
		return lst;
	}

	/**
	 * @param path
	 *            file
	 * @param cs
	 *            encode
	 * @return list of content
	 */
	public static List<String> readContentAsListPerLine(String path, String cs) {
		return readContentAsListPerLine(new File(path), cs);
	}

	/**
	 * @param file
	 *            path
	 * @return list of content with default encode
	 */
	public static List<String> readContentAsListPerLine(File file) {
		String cs = BytesReadTextCode.Detect(file);
		List<String> lst = new ArrayList<String>();
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), cs));
			for (String i = br.readLine(); null != i; i = br.readLine())
				lst.add(i.trim());
			br.close();
		} catch (Exception e) {
			System.err.println("Error in readContentAsListPerLine!");
			e.printStackTrace();
		}
		return lst;
	}

	/**
	 * @param path
	 *            file
	 * @return list of content with default encode
	 */
	public static List<String> readContentAsListPerLine(String path) {
		return readContentAsListPerLine(new File(path));
	}

	/**
	 * @param lst
	 *            content per line
	 * @param f
	 *            file
	 */
	public static void saveList(List<?> lst, File f) {
		File prt = f.getParentFile();
		if (!(prt.exists() && prt.isDirectory())) {
			prt.mkdirs();
		}
		try {
			PrintWriter pw = new PrintWriter(f);
			for (Object i : lst)
				pw.println(i);
			pw.flush();
			pw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param lst
	 *            content per line
	 * @param path
	 *            save path
	 */
	public static void saveList(List<?> lst, String path) {
		saveList(lst, new File(path));
	}

	/**
	 * @param words
	 *            lexicon needed
	 * @param path
	 *            embedding path
	 * @return embedding model where embedding of word exist in path file,
	 *         otherwise zero vector.
	 */
	public static VectorModel readVector(Set<String> words, String path) {
		if (null == path || path.isEmpty())
			return null;
		if (null == words || words.isEmpty())
			return null;

		VectorModel vm = new VectorModel();
		vm.vct = new TreeMap<String, double[]>();
		DataInputStream dis = null;
		try {
			dis = new DataInputStream(new BufferedInputStream(new FileInputStream(path)));
			vm.wordCount = dis.readInt();
			vm.volume = dis.readInt();
			for (int i = 0; i < vm.wordCount; i++) {
				String w = dis.readUTF().trim();
				double[] vct = new double[vm.volume];
				for (int j = 0; j < vct.length; j++)
					vct[j] = dis.readFloat();
				if (words.contains(w))
					vm.vct.put(w, vct);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (null != dis)
				try {
					dis.close();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
		}

		double[] v0 = zeroVector(vm.volume);
		for (String w : words)
			if (!vm.vct.containsKey(w))
				vm.vct.put(w, v0);

		return vm;
	}

	/**
	 * @param path
	 *            embedding path
	 * @return vector model with all words exist in path.
	 */
	public static VectorModel readVector(String path) {
		if (null == path || path.isEmpty())
			return null;

		VectorModel vm = new VectorModel();
		vm.vct = new TreeMap<String, double[]>();
		DataInputStream dis = null;
		try {
			dis = new DataInputStream(new BufferedInputStream(new FileInputStream(path)));
			vm.wordCount = dis.readInt();
			vm.volume = dis.readInt();
			for (int i = 0; i < vm.wordCount; i++) {
				if (0 == i % 10000)
					System.out.println("Embedding read " + (Math.round(1000.d * i / vm.wordCount) / 10.d) + "%");
				String w = dis.readUTF().trim();
				double[] vct = new double[vm.volume];
				for (int j = 0; j < vct.length; j++)
					vct[j] = dis.readFloat();
				vm.vct.put(w, vct);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (null != dis)
				try {
					dis.close();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
		}

		return vm;
	}

	public static void saveObject(Object obj, String path) {
		try {
			ObjectOutputStream oos = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(path)));
			oos.writeObject(obj);
			oos.flush();
			oos.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static Object readObject(String path) {
		try {
			ObjectInputStream ois = new ObjectInputStream(new BufferedInputStream(new FileInputStream(path)));
			Object obj = ois.readObject();
			ois.close();
			return obj;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
