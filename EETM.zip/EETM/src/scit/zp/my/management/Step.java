package scit.zp.my.management;

/**
 * Single step in framework of algorithms. Each step must extend this interface.
 * 
 * @author Peng
 *
 * @param <E>
 *            Specify the data type of the step.
 */
public abstract class Step<E> {
	public E dat;

	/**
	 * Implement the function in context of "call".
	 * 
	 * @return <i>true</i> if this step needs to iterative the whole procedure
	 *         for one more time, <i>false</i> otherwise.
	 */
	public abstract boolean call();

	/**
	 * Initialize the data of the step.
	 * 
	 * @param data
	 */
	public final void setData(E data) {
		this.dat = data;
	}
}
