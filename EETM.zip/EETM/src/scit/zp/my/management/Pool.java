package scit.zp.my.management;

public class Pool {
	public int CO_THREAD = 10240;
	public int WAIT_TIME = 10;

	private int p;

	public void reset() {
		this.p = 0;
	}

	public void creat() {
		synchronized (this) {
			this.p += 1;
		}
	}

	public void exit() {
		synchronized (this) {
			this.p -= 1;
		}
	}

	public void waitExt() {
		while (p > 0)
			try {
				Thread.sleep(this.WAIT_TIME);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
	}

	public void waitCrt() {
		while (p >= this.CO_THREAD)
			try {
				Thread.sleep(this.WAIT_TIME);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
	}
}
