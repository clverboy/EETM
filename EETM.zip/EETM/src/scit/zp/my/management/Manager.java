package scit.zp.my.management;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

public class Manager<E> {
	public E dat;
	public List<Step<E>> steps;

	public Manager() {
		this.steps = new LinkedList<Step<E>>();
	}

	public Manager(E data) {
		this();
		this.dat = data;
	}

	public Manager(E data, Collection<Step<E>> Steps) {
		this(data);
		this.steps.addAll(Steps);
		this.setDataIntoSteps();
	}

	public void addStep(Step<E> s) {
		s.setData(this.dat);
		this.steps.add(s);
	}

	public void setDataIntoSteps() {
		for (Step<E> i : this.steps)
			i.setData(this.dat);
	}

	public boolean runOnce() {
		boolean ctn = false;
		for (Step<E> i : this.steps)
			ctn = i.call() || ctn;

		// System.gc();

		return ctn;
	}

	public boolean runStep(int StepIndex) {
		return this.steps.get(StepIndex).call();
	}

	public void iterative(int maxTimes) {
		for (int tm = 0; maxTimes <= 0 || tm < maxTimes; tm += (maxTimes > 0) ? 1
				: 0)
			if (!this.runOnce())
				break;
	}

	public void iterative() {
		this.iterative(0);
	}
}
